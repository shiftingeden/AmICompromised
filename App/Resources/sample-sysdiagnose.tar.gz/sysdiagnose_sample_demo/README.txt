SAMPLE DATA for demonstrating Am I Compromised? It is not from a real device.
